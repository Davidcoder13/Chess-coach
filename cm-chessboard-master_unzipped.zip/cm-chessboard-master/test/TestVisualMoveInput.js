/**
 * Author and copyright: Stefan Haack (https://shaack.com)
 * Repository: https://github.com/shaack/cm-chessboard
 * License: MIT, see file 'LICENSE'
 */

import {describe, it, assert} from "../node_modules/teevi/src/teevi.js"
import {Chessboard} from "../src/Chessboard.js"
import {COLOR, INPUT_EVENT_TYPE} from "../src/view/ChessboardView.js"
import {MOVE_CANCELED_REASON} from "../src/view/VisualMoveInput.js"
import {FEN} from "../src/model/Position.js"

const STATE_WAIT_FOR_INPUT_START = "waitForInputStart"
const STATE_PIECE_CLICKED_THRESHOLD = "pieceClickedThreshold"
const STATE_CLICK_TO = "clickTo"
const STATE_DRAG_TO = "dragTo"

// Synthetic pointer events. The mouse path reads e.target / e.clientX directly,
// so it drives the real state machine without needing document.elementFromPoint.
const squareTarget = (name) => ({getAttribute: (n) => (n === "data-square" ? name : null)})
const mouseDown = (name, x = 100, y = 100) => ({
    type: "mousedown", button: 0, target: squareTarget(name),
    clientX: x, clientY: y, preventDefault: () => {}
})
const mouseMove = (name, x, y) => ({
    type: "mousemove", target: squareTarget(name), clientX: x, clientY: y, pageX: x, pageY: y
})
const mouseUp = (name) => ({type: "mouseup", target: squareTarget(name)})
const tick = () => new Promise((resolve) => setTimeout(resolve, 30))

function newBoard() {
    return new Chessboard(document.getElementById("TestBoard"), {
        assetsUrl: "../assets/",
        position: FEN.start,
        style: {animationDuration: 0}
    })
}

describe("TestVisualMoveInput", () => {

    it("should reset move input state on touchcancel", async () => {
        const chessboard = new Chessboard(document.getElementById("TestBoard"), {
            assetsUrl: "../assets/",
            position: FEN.start
        })
        chessboard.enableMoveInput(() => true)
        const visualMoveInput = chessboard.view.visualMoveInput

        visualMoveInput.onPointerDown({
            type: "touchstart",
            target: {getAttribute: (name) => (name === "data-square" ? "e2" : null)},
            touches: [{clientX: 100, clientY: 100}],
            preventDefault: () => {}
        })
        assert.equal(visualMoveInput.moveInputState, STATE_PIECE_CLICKED_THRESHOLD)

        window.dispatchEvent(new Event("touchcancel"))

        assert.equal(visualMoveInput.moveInputState, STATE_WAIT_FOR_INPUT_START)

        await new Promise((resolve) => setTimeout(resolve))
        chessboard.destroy()
    })

    // Regression for https://github.com/shaack/cm-chessboard/pull/174
    it("should validate once and finish the move when moving into own piece is marked as valid", async () => {
        const chessboard = new Chessboard(document.getElementById("TestBoard"), {
            assetsUrl: "../assets/",
            position: FEN.start
        })
        let validateCallCount = 0
        let moveInputFinishedCount = 0
        chessboard.enableMoveInput((event) => {
            if (event.type === INPUT_EVENT_TYPE.validateMoveInput) {
                validateCallCount++
                return true // accept the castling-by-clicking-the-rook move
            } else if (event.type === INPUT_EVENT_TYPE.moveInputFinished) {
                moveInputFinishedCount++
            }
            return true
        }, COLOR.white)
        const visualMoveInput = chessboard.view.visualMoveInput

        // simulate an existing click-to-move selection of the white king on e1
        visualMoveInput.moveInputStartedCallback("e1")
        visualMoveInput.moveInputState = STATE_CLICK_TO
        visualMoveInput.fromSquare = "e1"

        // castle by clicking the rook on h1 -> same-color-click branch
        visualMoveInput.onPointerDown({
            type: "touchstart",
            target: {getAttribute: (name) => (name === "data-square" ? "h1" : null)},
            touches: [{clientX: 100, clientY: 100}],
            preventDefault: () => {}
        })

        assert.equal(validateCallCount, 1)

        await new Promise((resolve) => setTimeout(resolve))
        // the move must complete (not get stuck in `clickTo`), firing moveInputFinished exactly once
        assert.equal(moveInputFinishedCount, 1)

        chessboard.destroy()
    })

    it("should complete a click-to-move (select, then click destination)", async () => {
        const board = newBoard()
        let finished = 0
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputFinished) finished++
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        assert.equal(vmi.moveInputState, STATE_CLICK_TO)

        vmi.onPointerDown(mouseDown("e4"))
        await tick()
        assert.equal(board.getPiece("e4"), "wp")
        assert.equal(board.getPiece("e2"), null)
        assert.equal(finished, 1)
        board.destroy()
    })

    // A click move always completes with its own animation (see the test above),
    // which is unwanted for premoves made by click. `event.animate = false` in the
    // validator lets a consumer opt out per-move instead of having to toggle
    // `chessboard.props.style.animationDuration` around the move.
    it("should skip a click move's own animation when the validator sets event.animate = false", async () => {
        const board = newBoard()
        let capturedAnimated = null
        const originalMovePiece = board.movePiece.bind(board)
        board.movePiece = (from, to, animated) => {
            capturedAnimated = animated
            return originalMovePiece(from, to, animated)
        }
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.validateMoveInput) {
                e.animate = false
                return true
            }
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        vmi.onPointerDown(mouseDown("e4"))
        await tick()

        assert.equal(capturedAnimated, false)
        assert.equal(board.getPiece("e4"), "wp")
        board.destroy()
    })

    it("should still animate a click move by default (event.animate untouched)", async () => {
        const board = newBoard()
        let capturedAnimated = null
        const originalMovePiece = board.movePiece.bind(board)
        board.movePiece = (from, to, animated) => {
            capturedAnimated = animated
            return originalMovePiece(from, to, animated)
        }
        board.enableMoveInput(() => true, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        vmi.onPointerDown(mouseDown("e4"))
        await tick()

        assert.equal(capturedAnimated, true)
        assert.equal(board.getPiece("e4"), "wp");
        board.destroy()
    })

    it("should complete a drag move to a new square", async () => {
        const board = newBoard()
        board.enableMoveInput(() => true, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2", 100, 100))
        vmi.onPointerMove(mouseMove("e4", 100, 140)) // past DRAG_THRESHOLD -> dragTo
        assert.equal(vmi.moveInputState, STATE_DRAG_TO)
        vmi.onPointerUp(mouseUp("e4"))
        await tick()
        assert.equal(board.getPiece("e4"), "wp")
        assert.equal(board.getPiece("e2"), null)
        board.destroy()
    })

    // Regression for https://github.com/shaack/cm-chessboard/issues/170 (PR #171)
    it("should cancel when a piece is dragged back to its origin", async () => {
        const board = newBoard()
        let canceledReason
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) canceledReason = e.reason
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2", 100, 100))
        vmi.onPointerMove(mouseMove("e2", 100, 140)) // -> dragTo
        assert.equal(vmi.moveInputState, STATE_DRAG_TO)
        vmi.onPointerUp(mouseUp("e2")) // dropped back on origin
        await tick()

        assert.equal(canceledReason, MOVE_CANCELED_REASON.draggedBack)
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        assert.equal(board.getPiece("e2"), "wp") // piece stays put
        board.destroy()
    })

    // Regression for https://github.com/shaack/cm-chessboard/issues/170
    it("should re-select when clicking another own piece", async () => {
        const board = newBoard()
        let canceledReason
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.validateMoveInput) return false // not a legal move onto own piece
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) canceledReason = e.reason
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        assert.equal(vmi.moveInputState, STATE_CLICK_TO)

        vmi.onPointerDown(mouseDown("d1")) // own white queen
        assert.equal(canceledReason, MOVE_CANCELED_REASON.clickedAnotherPiece)
        assert.equal(vmi.fromSquare, "d1")
        assert.equal(vmi.moveInputState, STATE_PIECE_CLICKED_THRESHOLD)
        await tick()
        board.destroy()
    })

    // Regression for https://github.com/shaack/cm-chessboard/pull/173
    it("should cancel an in-progress move on right click", async () => {
        const board = newBoard()
        let canceledReason
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) canceledReason = e.reason
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        assert.equal(vmi.moveInputState, STATE_CLICK_TO)

        vmi.onContextMenu({preventDefault: () => {}})
        assert.equal(canceledReason, MOVE_CANCELED_REASON.secondaryClick)
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        await tick()
        board.destroy()
    })

    it("should ignore input when move input is disabled", () => {
        const board = newBoard()
        const vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2"))
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        board.destroy()
    })

    it("should ignore a piece of the disabled color", () => {
        const board = newBoard()
        board.enableMoveInput(() => true, COLOR.white)
        const vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e7")) // black pawn, black input disabled
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        board.destroy()
    })

    it("should not start a move when moveInputStarted returns false", () => {
        const board = newBoard()
        board.enableMoveInput((e) => e.type !== INPUT_EVENT_TYPE.moveInputStarted, COLOR.white)
        const vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2"))
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        board.destroy()
    })

    // Regression for https://github.com/shaack/cm-chessboard/pull/165
    it("should cancel and keep the new position when the held piece is captured via setPosition", async () => {
        const board = newBoard()
        let canceled = null
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) canceled = {square: e.squareFrom, reason: e.reason}
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        assert.equal(vmi.moveInputState, STATE_CLICK_TO)

        // the opponent captures the held e2 pawn (e2 now holds a black knight)
        const capturedFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPnPPP/RNBQKBNR"
        await board.setPosition(capturedFen)

        assert.equal(canceled && canceled.reason, MOVE_CANCELED_REASON.movedPieceChanged)
        assert.equal(canceled && canceled.square, "e2") // the real start square, not null
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        // the position must not be corrupted back to the white pawn
        assert.equal("" + board.getPosition(), capturedFen)
        await tick()
        board.destroy()
    })

    it("should not cancel a normal move completion", async () => {
        const board = newBoard()
        let canceledReason
        let finished = 0
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) canceledReason = e.reason
            if (e.type === INPUT_EVENT_TYPE.moveInputFinished) finished++
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        vmi.onPointerDown(mouseDown("e4")) // completes via moveDone -> movePiece()
        await tick()
        assert.equal(board.getPiece("e4"), "wp")
        assert.equal(canceledReason, undefined) // the guard must prevent a spurious cancel
        assert.equal(finished, 1)
        board.destroy()
    })

    it("should cancel when the held piece is captured via movePiece or setPiece", async () => {
        // via setPiece
        let board = newBoard()
        let reason
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) reason = e.reason
            return true
        }, COLOR.white)
        let vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        await board.setPiece("e2", "bn")
        assert.equal(reason, MOVE_CANCELED_REASON.movedPieceChanged)
        await tick()
        board.destroy()

        // via movePiece (a black pawn captures onto e2)
        board = newBoard()
        reason = undefined
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) reason = e.reason
            return true
        }, COLOR.white)
        vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        await board.movePiece("d7", "e2")
        assert.equal(reason, MOVE_CANCELED_REASON.movedPieceChanged)
        await tick()
        board.destroy()
    })

    it("should cancel an in-progress click selection via cancelMoveInput()", async () => {
        const board = newBoard()
        let canceled = null
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) canceled = {square: e.squareFrom, reason: e.reason}
            return true
        }, COLOR.white)
        const vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        assert.equal(vmi.moveInputState, STATE_CLICK_TO)

        board.cancelMoveInput()
        assert.equal(canceled && canceled.reason, MOVE_CANCELED_REASON.canceled)
        assert.equal(canceled && canceled.square, "e2")
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        await tick()
        board.destroy()
    })

    it("should cancel a drag in progress via cancelMoveInput() without moving the piece", async () => {
        const board = newBoard()
        board.enableMoveInput(() => true, COLOR.white)
        const vmi = board.view.visualMoveInput
        vmi.onPointerDown(mouseDown("e2", 100, 100))
        vmi.onPointerMove(mouseMove("e4", 100, 140)) // -> dragTo
        assert.equal(vmi.moveInputState, STATE_DRAG_TO)

        board.cancelMoveInput()
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        assert.equal(board.getPiece("e2"), "wp")
        assert.equal(board.getPiece("e4"), null)
        await tick()
        board.destroy()
    })

    it("should be a no-op when cancelMoveInput() is called with no move in progress", () => {
        const board = newBoard()
        let canceledCount = 0
        board.enableMoveInput((e) => {
            if (e.type === INPUT_EVENT_TYPE.moveInputCanceled) canceledCount++
            return true
        }, COLOR.white)
        board.cancelMoveInput()
        assert.equal(canceledCount, 0)
        assert.equal(board.view.visualMoveInput.moveInputState, STATE_WAIT_FOR_INPUT_START)
        board.destroy()
    })

    // Regression: a piece selected by a mouse click (e.g. the compatibility mousedown/mouseup
    // iOS fires after a tap) installed only mouse listeners. Dragging it with a finger then
    // stuck in secondClickThreshold, every further touch ran into the void until a reload.
    it("should complete a touch drag of a piece that was selected by mouse", async () => {
        const board = newBoard()
        board.enableMoveInput(() => true, COLOR.white)
        const vmi = board.view.visualMoveInput

        vmi.onPointerDown(mouseDown("e2"))
        vmi.onPointerUp(mouseUp("e2"))
        assert.equal(vmi.moveInputState, STATE_CLICK_TO)

        vmi.onPointerDown({
            type: "touchstart", target: squareTarget("e2"),
            touches: [{clientX: 100, clientY: 100}], preventDefault: () => {}
        })
        const elementFromPoint = document.elementFromPoint
        document.elementFromPoint = () => squareTarget("e4")
        try {
            const touchMove = new Event("touchmove")
            touchMove.touches = [{clientX: 100, clientY: 140, pageX: 100, pageY: 140}]
            window.dispatchEvent(touchMove)
            assert.equal(vmi.moveInputState, "clickDragTo")
            const touchEnd = new Event("touchend")
            touchEnd.changedTouches = [{clientX: 100, clientY: 140}]
            window.dispatchEvent(touchEnd)
        } finally {
            document.elementFromPoint = elementFromPoint
        }
        await tick()
        assert.equal(board.getPiece("e4"), "wp")
        assert.equal(board.getPiece("e2"), null)
        assert.equal(vmi.moveInputState, STATE_WAIT_FOR_INPUT_START)
        board.destroy()
    })

})
